# Instructions for using the program

## How to install dependencies

```
pip3 install -r requirements.txt
```

## Before running the program

Please add the following file in your project directory: `data.xlsx`

## How to run the program

```
python3 app.py
```
