# Instructions for using the program

## How to install dependencies

```
pip3 install -r requirements.txt
```

# How to run the program

```
python3 app.py
```
